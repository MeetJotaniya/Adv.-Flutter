class UserModel {
  String? name;
  String? email;
  String? number;

  UserModel({this.name, this.email, this.number});
}
