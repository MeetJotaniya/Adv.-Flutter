class UserModel{
  String name;
  // String age;

  UserModel({required this.name});
}