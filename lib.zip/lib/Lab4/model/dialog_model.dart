class DialogModel {
  final String? title;
  final String? message;

  DialogModel({
    required this.title,
    required this.message,
  });
}
