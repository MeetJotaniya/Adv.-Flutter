import 'package:get/get.dart';

class ShowHideController{

  RxBool isShow = false.obs;

}