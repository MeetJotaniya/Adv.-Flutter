import 'package:get/get.dart';

class TextFieldController extends GetxController {
  RxString inputText = ''.obs;
}